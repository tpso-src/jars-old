These samples are being tested with the anteater webapp automated testing scripts. 

Please don't modify things in this directory without modifying
the appropriate Anteater scripts in src/test/anteater/.

Thanks.