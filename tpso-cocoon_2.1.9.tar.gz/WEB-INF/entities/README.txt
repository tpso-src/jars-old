See Apache Cocoon documentation
"Entity resolution with catalogs" (catalog.html)

Please keep these resources in sync with the authoritative stuff at Forrest.
